// Copyright (c) 2016-2025 CloudMakers, s. r. o.
// All rights reserved.
//
// You can use this software under the terms of 'INDIGO Astronomy
// open-source license' (see LICENSE.md).
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHORS 'AS IS' AND ANY EXPRESS
// OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// version history
// 2.0 by Peter Polakovic <peter.polakovic@cloudmakers.eu>

/** INDIGO client
 \file indigo_client.h
 */

#ifndef indigo_client_h
#define indigo_client_h
#include <pthread.h>
#include <stdbool.h>
#include <indigo/indigo_bus.h>
//#include <indigo/indigo_driver.h>

#if defined(INDIGO_WINDOWS)
#if defined(INDIGO_WINDOWS_DLL)
#define INDIGO_EXTERN __declspec(dllexport)
#else
#define INDIGO_EXTERN __declspec(dllimport)
#endif
#else
#define INDIGO_EXTERN extern
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define INDIGO_MAX_SERVERS    10

/** Use <enableBLOB>URL</enableBLOB> for remote INDIGO servers;
 *  defined in indigo_xml.c
 */
INDIGO_EXTERN bool indigo_use_blob_urls;

/** Client name used for enumeration requests to set adapter name on server side for client identification in trace logs. Defaults to argv[0]
 */

INDIGO_EXTERN char *indigo_client_name;

#define INDIGO_MAX_DRIVERS    256

/** Driver entry type.
 */
typedef struct {
	char description[INDIGO_NAME_SIZE];     ///< driver description
	char name[INDIGO_NAME_SIZE];            ///< driver name (entry point name)
	driver_entry_point driver;              ///< driver entry point
#if defined(INDIGO_LINUX) || defined(INDIGO_MACOS)
	void *dl_handle;                        ///< dynamic library handle (NULL for statically linked driver)
#elif defined(INDIGO_WINDOWS)
	HMODULE dl_handle;                        ///< dynamic library handle (NULL for statically linked driver)
#endif
	bool initialized;												///< driver is initialized
} indigo_driver_entry;

/** Array of all available drivers (statically & dynamically linked).
 */
INDIGO_EXTERN indigo_driver_entry indigo_available_drivers[INDIGO_MAX_DRIVERS];

/** Add statically linked driver.
 */
INDIGO_EXTERN indigo_result indigo_add_driver(driver_entry_point entry_point, bool init, indigo_driver_entry** driver);

/** Check if the driver is initialized, This function is not protected by mutex so it must be called in synchronized sections.
		Its intended useage is in driver entrypoints.
 */
INDIGO_EXTERN bool indigo_driver_initialized(char* driver_name);

/** Remove statically linked driver or remove & unload dynamically linked driver
 */
INDIGO_EXTERN indigo_result indigo_remove_driver(indigo_driver_entry* driver);

/** Load & add dynamically linked driver.
 */
INDIGO_EXTERN indigo_result indigo_load_driver(const char* name, bool init, indigo_driver_entry** driver);

#if defined(INDIGO_LINUX) || defined(INDIGO_MACOS)

typedef struct indigo_subprocess_entry indigo_subprocess_entry;

/** Remote executable entry type.
 */
typedef struct indigo_subprocess_entry {
	char executable[INDIGO_NAME_SIZE];      ///< executable path name
	pthread_t thread;                       ///< client thread ID
	bool thread_started;                    ///< client thread started/stopped
	int pid;                                ///< process pid
	indigo_device *protocol_adapter;        ///< server protocol adapter
	char last_error[256];                   ///< last error reported within client thread
	bool *connection_state;                 ///< pointer to connection state variable to be set within client thread
} indigo_subprocess_entry;

/** Array of all available subprocesses.
 */
INDIGO_EXTERN indigo_subprocess_entry indigo_available_subprocesses[INDIGO_MAX_SERVERS];

/** Start thread for subprocess.
 */
INDIGO_EXTERN indigo_result indigo_start_subprocess(const char *executable, indigo_subprocess_entry **subprocess, bool *connection_state);

/** Stop thread for subprocess.
 */
INDIGO_EXTERN indigo_result indigo_kill_subprocess(indigo_subprocess_entry *subprocess);

#endif

typedef struct indigo_server_entry indigo_server_entry;

/** Remote server entry type.
 */
typedef struct indigo_server_entry {
	char name[INDIGO_NAME_SIZE];            ///< service name
	char host[INDIGO_NAME_SIZE];            ///< server host name
	int port;                               ///< server port
	uint32_t connection_id;                 ///< client connection ID
	pthread_t thread;                       ///< client thread ID
	bool thread_started;                    ///< client thread started/stopped
	indigo_uni_handle *handle;              ///< stream socket
	indigo_device *protocol_adapter;        ///< server protocol adapter
	bool shutdown;                          ///< request shutdown
	bool *connection_state;                 ///< pointer to connection state variable to be set within client thread
} indigo_server_entry;

/** Array of all available servers.
 */
INDIGO_EXTERN indigo_server_entry indigo_available_servers[INDIGO_MAX_SERVERS];

/** Create bonjour service name.
 */
INDIGO_EXTERN void indigo_service_name(const char *host, int port, char *name);

/** Connect and start thread for remote server.
 */
INDIGO_EXTERN indigo_result indigo_connect_server(const char *name, const char *host, int port, indigo_server_entry **server, bool *connection_state);
INDIGO_EXTERN indigo_result indigo_connect_server_id(const char *name, const char *host, int port, uint32_t connection_id, indigo_server_entry **server, bool *connection_state);

/** Disconnect and stop thread for remote server.
 */
INDIGO_EXTERN indigo_result indigo_disconnect_server(indigo_server_entry *server);

/** Format item to string.
 */
INDIGO_EXTERN indigo_result indigo_format_number(char *buffer, int buffer_size, char *format, double value);

#ifdef __cplusplus
}
#endif

#endif /* indigo_client_h */
