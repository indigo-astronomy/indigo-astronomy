// Copyright (c) 2016-2025 CloudMakers, s. r. o.
// All rights reserved.
//
// You can use this software under the terms of 'INDIGO Astronomy
// open-source license' (see LICENSE.md).
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHORS 'AS IS' AND ANY EXPRESS
// OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
// DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
// GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
// WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// version history
// 2.0 by Peter Polakovic <peter.polakovic@cloudmakers.eu>

/** INDIGO Build configuration
 \file indigo_config.h
 */

#ifndef indigo_config_h
#define indigo_config_h

#if defined(INDIGO_WINDOWS)
#if defined(INDIGO_WINDOWS_DLL)
#define INDIGO_EXTERN __declspec(dllexport)
#else
#define INDIGO_EXTERN __declspec(dllimport)
#endif
#else
#define INDIGO_EXTERN extern
#endif

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/** INDIGO version (major in high byte, minor in low byte).
    Used to initialise INDIGO_VERSION_CURRENT in indigo_bus.h. The top-level
    Makefile keeps this constant in sync with INDIGO_VERSION.
 */
#define INDIGO_VERSION_MAJOR_MINOR 0x0300

/** INDIGO Build number. The top-level Makefile keeps this constant
    in sync with INDIGO_BUILD.
 */
#define INDIGO_BUILD "8"

/** INDIGO Build commit
 */
#if defined(INDIGO_WINDOWS)
#define INDIGO_BUILD_COMMIT ""
#else
#define INDIGO_BUILD_COMMIT indigo_build_commit
INDIGO_EXTERN char *indigo_build_commit;
#endif

/** INDIGO Build time
 */
#if defined(INDIGO_WINDOWS)
#define INDIGO_BUILD_TIME __DATE__
#else
#define INDIGO_BUILD_TIME indigo_build_time
INDIGO_EXTERN char *indigo_build_time;
#endif

/** Vesrtion major and minor
 */
#define INDIGO_VERSION_MAJOR(ver) (((ver) >> 8) & 0xFF)
#define INDIGO_VERSION_MINOR(ver) ((ver) & 0xFF)

/** Conditional compilation wrapper for TRACE log level
 */
#define INDIGO_TRACE(c) c

/** Conditional compilation wrapper for DEBUG log level
 */
#define INDIGO_DEBUG(c) c

/** Conditional compilation wrapper for ERROR log level
 */
#define INDIGO_ERROR(c) c

/** Conditional compilation wrapper for LOG log level
 */
#define INDIGO_LOG(c) c

/** Conditional compilation wrapper for TRACE log level (for wire protocol adapters)
 */
#define INDIGO_TRACE_PROTOCOL(c) c

/** Conditional compilation wrapper for TRACE log level (for wire protocol parsers)
 */
#define INDIGO_TRACE_PARSER(c)

/** Conditional compilation wrapper for DEBUG log level (for wire protocol adapters)
 */
#define INDIGO_DEBUG_PROTOCOL(c) c

/** Conditional compilation wrapper for TRACE log level (for drivers)
 */
#define INDIGO_TRACE_DRIVER(c) c

/** Conditional compilation wrapper for DEBUG log level (for drivers)
 */
#define INDIGO_DEBUG_DRIVER(c) c

#endif /* indigo_config_h */
